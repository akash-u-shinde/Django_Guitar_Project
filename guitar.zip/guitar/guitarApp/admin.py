from django.contrib import admin

from .models import *

admin.site.register(YoutubeVideos)
admin.site.register(AboutGuitar)
admin.site.register(Batches)
admin.site.register(Feestructure)
admin.site.register(Buyguitar)
admin.site.register(Post)